Authors:
Prasham Walvekar (CS21BTECH11047)
Kallu Rithika (AI22BTECH11010)
Armaan (CS22BTECH11051)

Dependencies:
Make sure conda is installed.
Make sure GPU is available, with large VRAM. (We used A100 GPU with 40-80GB VRAM)

Steps to setup the environment:
conda create --name nlp python=3.9
conda activate nlp
conda install numpy pandas scikit-learn matplotlib tqdm
pip install transformers
pip install torch --index-url https://download.pytorch.org/whl/cu121 #(For the CUDA version we used - 12.1)
pip install lime

Once the environment is set up, make sure the data is in the following structure:

data->train->eng.csv
             mar.csv
             hindi.csv

data->test ->eng.csv
             mar.csv
             hindi.csv

Choose the appropriate kernel and run the following python notebooks:
english.ipynb
multilingual.ipynb
